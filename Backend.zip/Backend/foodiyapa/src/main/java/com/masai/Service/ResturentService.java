package com.masai.Service;

import java.util.List;

import com.masai.Exception.FoodiyapaException;
import com.masai.models.Resturant;

public interface ResturentService {

	public Resturant addResturant(Resturant resturent);
	public List<Resturant> getAllResturant();
	public Resturant updateResturantName(int id, String resturentname) throws FoodiyapaException;
	public Resturant updateResturantaddress(int id, String resturantaddress) throws FoodiyapaException;
	public String deleteResturant(int id) throws FoodiyapaException;
}
