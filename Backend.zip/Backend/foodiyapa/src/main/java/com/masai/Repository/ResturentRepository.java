package com.masai.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.masai.models.Resturant;

public interface ResturentRepository extends JpaRepository<Resturant, Integer> {

}
