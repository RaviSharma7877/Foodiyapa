package com.masai.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.masai.Exception.FoodiyapaException;
import com.masai.Repository.ResturentRepository;
import com.masai.models.Customer;
import com.masai.models.Resturant;

@Service
public class ResturentServiceImpl implements ResturentService {

	private ResturentRepository rRepo;
	
	
	public ResturentServiceImpl(ResturentRepository rRepo) {
		super();
		this.rRepo = rRepo;
	}

	@Override
	public Resturant addResturant(Resturant resturent) {
		// TODO Auto-generated method stub
		return rRepo.save(resturent);
	}

	@Override
	public List<Resturant> getAllResturant() {
		// TODO Auto-generated method stub
		return rRepo.findAll();
	}

	@Override
	public Resturant updateResturantName(int id, String resturentname) throws FoodiyapaException {
		Resturant c = rRepo.findById(id).orElseThrow(() -> new FoodiyapaException("No product found for id "+ id));
		c.setResturantname(resturentname);
		return c;
	}
	
	@Override
	public Resturant updateResturantaddress(int id, String resturantaddress) throws FoodiyapaException {
		Resturant c = rRepo.findById(id).orElseThrow(() -> new FoodiyapaException("No product found for id "+ id));
		c.setResturantaddress(resturantaddress);
		return c;
	}

	@Override
	public String deleteResturant(int id) throws FoodiyapaException {
		Resturant c = rRepo.findById(id).orElseThrow(() -> new FoodiyapaException("No product found for id "+ id));
		rRepo.delete(c);
		return "Customer deleted successfully";
	}

}
