package com.masai.Exception;

public class FoodiyapaException extends Exception {

	public FoodiyapaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
