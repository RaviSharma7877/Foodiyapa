package com.masai.Service;

import java.util.List;

import com.masai.Exception.FoodiyapaException;
import com.masai.models.Customer;
import com.masai.models.Users;

public interface UserService {

	public Users addUser(Users customer);
}
