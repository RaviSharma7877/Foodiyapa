package com.masai.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.masai.Exception.FoodiyapaException;
import com.masai.Service.ResturentService;
import com.masai.models.Resturant;

@RestController
public class ResturentController {

	private ResturentService rService;

	public ResturentController(ResturentService rS) {
		super();
		this.rService = rS;
	}
	
	@PostMapping("/resturent")
	public ResponseEntity<Resturant> addResturant(@RequestBody Resturant resturent) {
		return new ResponseEntity<Resturant>(rService.addResturant(resturent),HttpStatus.CREATED);
	}
	
	@GetMapping("/resturent")
	public ResponseEntity<List<Resturant>> getAllResturant() {
		return new ResponseEntity<List<Resturant>>(rService.getAllResturant(),HttpStatus.OK);
	}
	
	@PostMapping("/resturents/{id}")
	public ResponseEntity<Resturant> updateResturantName(@PathVariable int id, @RequestParam String resturentname) throws FoodiyapaException {
		return new ResponseEntity<Resturant>(rService.updateResturantName(id,resturentname),HttpStatus.OK);
	}
	
	@PostMapping("/resturent/{id}")
	public ResponseEntity<Resturant> updateResturantaddress(@PathVariable int id, @RequestParam String resturantaddress) throws FoodiyapaException {
		return new ResponseEntity<Resturant>(rService.updateResturantaddress(id,resturantaddress),HttpStatus.OK);
	}
	
	@DeleteMapping("/resturent/{id}")
	public ResponseEntity<String> deleteResturant(@PathVariable int id) throws FoodiyapaException {
		return new ResponseEntity<String>(rService.deleteResturant(id),HttpStatus.OK);
	}
}
