package com.masai.models;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Resturant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int resturentId;
	
	@OneToMany(mappedBy = "resturant")
	private List<Orders> orders;
	
	@ManyToOne
    private Product resturantmenu;
    private String resturantname;
    private String resturantaddress;
	public Resturant() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Resturant(List<Orders> orders, Product resturantmenu, String resturantname, String resturantaddress) {
		super();
		this.orders = orders;
		this.resturantmenu = resturantmenu;
		this.resturantname = resturantname;
		this.resturantaddress = resturantaddress;
	}
	public int getResturentId() {
		return resturentId;
	}
	public List<Orders> getOrders() {
		return orders;
	}
	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}
	public Product getResturantmenu() {
		return resturantmenu;
	}
	public void setResturantmenu(Product resturantmenu) {
		this.resturantmenu = resturantmenu;
	}
	public String getResturantname() {
		return resturantname;
	}
	public void setResturantname(String resturantname) {
		this.resturantname = resturantname;
	}
	public String getResturantaddress() {
		return resturantaddress;
	}
	public void setResturantaddress(String resturantaddress) {
		this.resturantaddress = resturantaddress;
	}
    

}
