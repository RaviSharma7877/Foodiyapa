package com.masai.exceptions;

public class FoodiyapaException extends RuntimeException {

	public FoodiyapaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
