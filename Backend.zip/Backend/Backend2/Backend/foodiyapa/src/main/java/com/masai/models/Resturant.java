package com.masai.models;

import java.awt.MenuItem;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.criteria.Order;
import lombok.Data;

@Entity
@Data
public class Resturant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int resturentId;
	
	@OneToMany(mappedBy = "resturant")
	private List<Order> orders;
	
	@ManyToOne
    private List<Product> menu;
    private String name;
    private String address;
    

}
