package com.masai.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.masai.exceptions.FoodiyapaException;
import com.masai.models.Customer;
import com.masai.repository.CustomerRepository;
import com.masai.services.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository customerRepo;
	

	public CustomerServiceImpl(CustomerRepository customerRepo) {
		super();
		this.customerRepo = customerRepo;
	}

	@Override
	public Customer addCustomer(Customer customer) {
        return customerRepo.save(customer);
	}

	@Override
	public List<Customer> getAllCustomer() {
		return customerRepo.findAll();
	}

	@Override
	public Customer updateCustomerEmail(int id, String email) throws FoodiyapaException {
		Customer c = customerRepo.findById(id).orElseThrow(() -> new FoodiyapaException("No product found for id "+ id));
		
		c.setEmail(email);
		return c;
	}

	@Override
	public String deleteCustomer(int id) {
		Customer c = customerRepo.findById(id).orElseThrow(() -> new FoodiyapaException("No product found for id "+ id));
		customerRepo.delete(c);
		return "Customer deleted successfully";
	}

}
