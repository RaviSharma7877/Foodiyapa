package com.masai.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masai.exceptions.FoodiyapaException;
import com.masai.models.Customer;
import com.masai.services.CustomerService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
public class CustomerController {

//	@Autowired
	private CustomerService customerService;
	
	
	

	public CustomerController(CustomerService customerService) {
	super();
	this.customerService = customerService;
}

	@PostMapping("/customer")
	public ResponseEntity<Customer> addCustomer(Customer customer){
		return new ResponseEntity<Customer>(customerService.addCustomer(customer),HttpStatus.CREATED);
	}
	
	@GetMapping("/customer")
	public ResponseEntity<List<Customer>> getAllCustomer(){
		return new ResponseEntity<List<Customer>>(customerService.getAllCustomer(),HttpStatus.OK);
	}
	
	@PostMapping("/cutomer/{id}")
	public ResponseEntity<Customer> updateCustomerEmail(@PathVariable int id,@RequestBody String email) throws FoodiyapaException{
		return new ResponseEntity<Customer>(customerService.updateCustomerEmail(id, email),HttpStatus.OK);
	}
	
	@DeleteMapping("/customer")
	public ResponseEntity<String> deleteCustomer(int id){
		return new ResponseEntity<String>(customerService.deleteCustomer(id),HttpStatus.OK);
	}
}
