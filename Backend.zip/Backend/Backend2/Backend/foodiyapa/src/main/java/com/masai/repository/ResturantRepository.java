package com.masai.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.masai.models.Resturant;

public interface ResturantRepository extends JpaRepository<Resturant, Integer>, PagingAndSortingRepository<Resturant, Integer> {

}
