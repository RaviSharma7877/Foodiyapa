package com.masai.models;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class DeliveryPartner {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int partnerId;
    private String name;
    private String vehicleType;
    private String driverMobile;
    
    @OneToMany(mappedBy = "deliveryPartner")
    private List<Orders> orders;

}
