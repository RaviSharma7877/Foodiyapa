package com.masai.models;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class Orders {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderId;
	
	@ManyToOne
    private Customer customer;
	@ManyToOne
    private DeliveryPartner deliveryPartner;
	
	@OneToMany(mappedBy = "orders")
    private List<Product> items;
    private double totalAmount;
    private boolean isDelivered;
    
    @ManyToOne
    private Resturant resturant;
    

}
