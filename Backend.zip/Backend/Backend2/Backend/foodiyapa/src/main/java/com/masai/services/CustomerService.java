package com.masai.services;

import java.util.List;

import com.masai.exceptions.FoodiyapaException;
import com.masai.models.Customer;

public interface CustomerService {

	public Customer addCustomer(Customer customer);
	
	public List<Customer> getAllCustomer();
	
	public Customer updateCustomerEmail(int id, String email)throws FoodiyapaException;
	
	public String deleteCustomer(int id);
}
