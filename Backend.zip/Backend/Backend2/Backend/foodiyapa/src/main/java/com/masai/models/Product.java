package com.masai.models;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productId;
	private String img;
	private String productName;
	private int price;
	private String description;
	
	@OneToMany(mappedBy = "menu")
	private List<Resturant> resturant;
	
	@ManyToOne
	private Orders orders;

	
}
